## Au préalable
Vérifier d'avoir une version node au dessus de 14.0.0

## Installation
Grâce à une invit de commande, utiliser la commande : npm install pour toutes les dépendances de gulp.

## Utilisation
Lorsque l'installation n'a rencontré aucune erreur, à partir de l'invit de commande, il vous suffit d'utiliser la commande gulp dans le dossier CV.